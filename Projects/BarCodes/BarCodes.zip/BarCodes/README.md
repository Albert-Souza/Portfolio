# BarCodes

A software that generates and reads barcodes.  

---  
## Execution
  
To run the program, it is necessary to have JRE(Java Runtime Environment) installed.  

1\. Open a terminal in the `BarCodes` directory.  
2\. Use the command: `java BarCodes`.  

## Usage
  
Click the `Generate Bar Code` button to generate a code.  
Click `Save` to save the code to the Bars directory.  
Click the `Read Bar Code` button to open a saved code on your computer.  
